
package forms;

import domain.Area;

public class BrotherhoodForm {

	private Area	area;


	public Area getArea() {
		return this.area;
	}

	public void setArea(final Area area) {
		this.area = area;
	}

}
