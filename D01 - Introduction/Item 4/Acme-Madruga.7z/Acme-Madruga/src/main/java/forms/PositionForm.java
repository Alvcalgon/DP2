
package forms;

public class PositionForm {

	// Attributes ---------------------
	private int		id;
	private String	en_name;
	private String	es_name;


	public int getId() {
		return this.id;
	}

	public void setId(final int id) {
		this.id = id;
	}

	public String getEn_name() {
		return this.en_name;
	}

	public void setEn_name(final String en_name) {
		this.en_name = en_name;
	}

	public String getEs_name() {
		return this.es_name;
	}

	public void setEs_name(final String es_name) {
		this.es_name = es_name;
	}

}
